﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TopClearSc : MonoBehaviour {

    public int topLevel = 1;
    public Text topLevelText;

    public void Update()
    {
        topLevelText.text = "현재: " + topLevel+"층";
    }

    public void GetLife()
    {
        topLevel++;
        
        //CheckGameOver();
    }
}
