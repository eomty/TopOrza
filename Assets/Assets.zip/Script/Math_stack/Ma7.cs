﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ma7 : MonoBehaviour
{
    // Start is called before the first frame update
    void Awake()
    {
        TopClearSC TCSC = GameObject.Find("GameManager").GetComponent<TopClearSC>();
        TCSC.level_stack = 7;
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
