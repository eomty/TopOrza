﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeScene : MonoBehaviour
{

    public GameObject ChooseSceneIMG; // 씬 고르기 이미지
    
    public void ChooseScene()
    {
        GameObject.Instantiate(ChooseSceneIMG);//씬 고르기 이미지 출력
    }

    public GameObject SaveLoadImg;

    public void SaveLoad() // 저장&불러오기 씬 이미지
    {
        GameObject.Instantiate(SaveLoadImg);
    }

    public GameObject OptionIMG; // 옵션 이미지

    public void ViewOption()
    {
        GameObject.Instantiate(OptionIMG);
    }



    //구성 씬
    public void ChangeTo_StartScene()
    {
        SceneManager.LoadScene("StartS");//시작화면 씬 : 게임 시작할 때 나오는 화면
    }
    public void ChangeTo_LoadingScene()
    {
        SceneManager.LoadScene("LoadingS");//로딩화면 호출
    }
    public void ChangeTo_MainScene()
    {
        SceneManager.LoadScene("MainS");//메인 화면 씬:뒤로가면 시작화면으로 이동하고, 탑 오르거나 명예의 탑, 옵션(모드)를 선택 가능
    }
    public void ChangeTo_FameTowerScene()
    {
        SceneManager.LoadScene("FameTS"); //명예의 탑
    }
    public void ChangeTo_Test1Scene()
    {
        SceneManager.LoadScene("Test1S"); // 임시 저장된거 불러오기
    }



    //아래는 탑 씬들 나중에 1~15층까지 늘릴거임


    //1층

    public void ChangeTo_MathTower_1_Scene()
    {
        SceneManager.LoadScene("Math_1TS");
    }
    public void ChangeTo_LuckyTower_1_Scene()
    {
        SceneManager.LoadScene("Luck_1TS");
    }
    public void ChangeTo_MageTower_1_Scene()
    {
        SceneManager.LoadScene("Mage_1TS");
    }
    public void ChangeTo_RunTower_1_Scene()
    {
        SceneManager.LoadScene("Run_1TS");
    }
    public void ChangeTo_JumpTower_1_Scene()
    {
        SceneManager.LoadScene("Jump_1TS");
    }
    public void ChangeTo_ClimbTower_1_Scene()
    {
        SceneManager.LoadScene("Climb_1TS");
    }
    public void ChangeTo_TimingTower_1_Scene()
    {
        SceneManager.LoadScene("Timing_1TS");
    }
    public void ChangeTo_OneHandDrowingTower_1_Scene()
    {
        SceneManager.LoadScene("OHD_1TS");
    }
    public void ChangeTo_DeviceTower_1_Scene()
    {
        SceneManager.LoadScene("Device_1TS");
    }

        //2층
    public void ChangeTo_MathTower_2_Scene()
    {
        SceneManager.LoadScene("Math_2TS");
    }
    public void ChangeTo_LuckyTower_2_Scene()
    {
        SceneManager.LoadScene("Luck_2TS");
    }
    public void ChangeTo_MageTower_2_Scene()
    {
        SceneManager.LoadScene("Mage_2TS");
    }
    public void ChangeTo_RunTower_2_Scene()
    {
        SceneManager.LoadScene("Run_2TS");
    }
    public void ChangeTo_JumpTower_2_Scene()
    {
        SceneManager.LoadScene("Jump_2TS");
    }
    public void ChangeTo_ClimbTower_2_Scene()
    {
        SceneManager.LoadScene("Climb_2TS");
    }
    public void ChangeTo_TimingTower_2_Scene()
    {
        SceneManager.LoadScene("Timing_2TS");
    }
    public void ChangeTo_OneHandDrowingTower_2_Scene()
    {
        SceneManager.LoadScene("OHD_2TS");
    }
    public void ChangeTo_DeviceTower_2_Scene()
    {
        SceneManager.LoadScene("Device_2TS");
    }


    //3층
    public void ChangeTo_MathTower_3_Scene()
    {
        SceneManager.LoadScene("Math_3TS");
    }
    public void ChangeTo_LuckyTower_3_Scene()
    {
        SceneManager.LoadScene("Luck_3TS");
    }
    public void ChangeTo_MageTower_3_Scene()
    {
        SceneManager.LoadScene("Mage_3TS");
    }
    public void ChangeTo_RunTower_3_Scene()
    {
        SceneManager.LoadScene("Run_3TS");
    }
    public void ChangeTo_JumpTower_3_Scene()
    {
        SceneManager.LoadScene("Jump_3TS");
    }
    public void ChangeTo_ClimbTower_3_Scene()
    {
        SceneManager.LoadScene("Climb_3TS");
    }
    public void ChangeTo_TimingTower_3_Scene()
    {
        SceneManager.LoadScene("Timing_3TS");
    }
    public void ChangeTo_OneHandDrowingTower_3_Scene()
    {
        SceneManager.LoadScene("OHD_3TS");
    }
    public void ChangeTo_DeviceTower_3_Scene()
    {
        SceneManager.LoadScene("Device_3TS");
    }

    //4층
    public void ChangeTo_MathTower_4_Scene()
    {
        SceneManager.LoadScene("Math_4TS");
    }
    public void ChangeTo_LuckyTower_4_Scene()
    {
        SceneManager.LoadScene("Luck_4TS");
    }
    public void ChangeTo_MageTower_4_Scene()
    {
        SceneManager.LoadScene("Mage_4TS");
    }
    public void ChangeTo_RunTower_4_Scene()
    {
        SceneManager.LoadScene("Run_4TS");
    }
    public void ChangeTo_JumpTower_4_Scene()
    {
        SceneManager.LoadScene("Jump_4TS");
    }
    public void ChangeTo_ClimbTower_4_Scene()
    {
        SceneManager.LoadScene("Climb_4TS");
    }
    public void ChangeTo_TimingTower_4_Scene()
    {
        SceneManager.LoadScene("Timing_4TS");
    }
    public void ChangeTo_OneHandDrowingTower_4_Scene()
    {
        SceneManager.LoadScene("OHD_4TS");
    }
    public void ChangeTo_DeviceTower_4_Scene()
    {
        SceneManager.LoadScene("Device_4TS");
    }


    //5층
    public void ChangeTo_MathTower_5_Scene()
    {
        SceneManager.LoadScene("Math_5TS");
    }
    public void ChangeTo_LuckyTower_5_Scene()
    {
        SceneManager.LoadScene("Luck_5TS");
    }
    public void ChangeTo_MageTower_5_Scene()
    {
        SceneManager.LoadScene("Mage_5TS");
    }
    public void ChangeTo_RunTower_5_Scene()
    {
        SceneManager.LoadScene("Run_5TS");
    }
    public void ChangeTo_JumpTower_5_Scene()
    {
        SceneManager.LoadScene("Jump_5TS");
    }
    public void ChangeTo_ClimbTower_5_Scene()
    {
        SceneManager.LoadScene("Climb_5TS");
    }
    public void ChangeTo_TimingTower_5_Scene()
    {
        SceneManager.LoadScene("Timing_5TS");
    }
    public void ChangeTo_OneHandDrowingTower_5_Scene()
    {
        SceneManager.LoadScene("OHD_5TS");
    }
    public void ChangeTo_DeviceTower_5_Scene()
    {
        SceneManager.LoadScene("Device_5TS");
    }


    //6층
    public void ChangeTo_MathTower_6_Scene()
    {
        SceneManager.LoadScene("Math_6TS");
    }
    public void ChangeTo_LuckyTower_6_Scene()
    {
        SceneManager.LoadScene("Luck_6TS");
    }
    public void ChangeTo_MageTower_6_Scene()
    {
        SceneManager.LoadScene("Mage_6TS");
    }
    public void ChangeTo_RunTower_6_Scene()
    {
        SceneManager.LoadScene("Run_6TS");
    }
    public void ChangeTo_JumpTower_6_Scene()
    {
        SceneManager.LoadScene("Jump_6TS");
    }
    public void ChangeTo_ClimbTower_6_Scene()
    {
        SceneManager.LoadScene("Climb_6TS");
    }
    public void ChangeTo_TimingTower_6_Scene()
    {
        SceneManager.LoadScene("Timing_6TS");
    }
    public void ChangeTo_OneHandDrowingTower_6_Scene()
    {
        SceneManager.LoadScene("OHD_6TS");
    }
    public void ChangeTo_DeviceTower_6_Scene()
    {
        SceneManager.LoadScene("Device_6TS");
    }


    //7층
    public void ChangeTo_MathTower_7_Scene()
    {
        SceneManager.LoadScene("Math_7TS");
    }
    public void ChangeTo_LuckyTower_7_Scene()
    {
        SceneManager.LoadScene("Luck_7TS");
    }
    public void ChangeTo_MageTower_7_Scene()
    {
        SceneManager.LoadScene("Mage_7TS");
    }
    public void ChangeTo_RunTower_7_Scene()
    {
        SceneManager.LoadScene("Run_7TS");
    }
    public void ChangeTo_JumpTower_7_Scene()
    {
        SceneManager.LoadScene("Jump_7TS");
    }
    public void ChangeTo_ClimbTower_7_Scene()
    {
        SceneManager.LoadScene("Climb_7TS");
    }
    public void ChangeTo_TimingTower_7_Scene()
    {
        SceneManager.LoadScene("Timing_7TS");
    }
    public void ChangeTo_OneHandDrowingTower_7_Scene()
    {
        SceneManager.LoadScene("OHD_7TS");
    }
    public void ChangeTo_DeviceTower_7_Scene()
    {
        SceneManager.LoadScene("Device_7TS");
    }


    //8층
    public void ChangeTo_MathTower_8_Scene()
    {
        SceneManager.LoadScene("Math_8TS");
    }
    public void ChangeTo_LuckyTower_8_Scene()
    {
        SceneManager.LoadScene("Luck_8TS");
    }
    public void ChangeTo_MageTower_8_Scene()
    {
        SceneManager.LoadScene("Mage_8TS");
    }
    public void ChangeTo_RunTower_8_Scene()
    {
        SceneManager.LoadScene("Run_8TS");
    }
    public void ChangeTo_JumpTower_8_Scene()
    {
        SceneManager.LoadScene("Jump_8TS");
    }
    public void ChangeTo_ClimbTower_8_Scene()
    {
        SceneManager.LoadScene("Climb_8TS");
    }
    public void ChangeTo_TimingTower_8_Scene()
    {
        SceneManager.LoadScene("Timing_8TS");
    }
    public void ChangeTo_OneHandDrowingTower_8_Scene()
    {
        SceneManager.LoadScene("OHD_8TS");
    }
    public void ChangeTo_DeviceTower_8_Scene()
    {
        SceneManager.LoadScene("Device_8TS");
    }


    //9층
    public void ChangeTo_MathTower_9_Scene()
    {
        SceneManager.LoadScene("Math_9TS");
    }
    public void ChangeTo_LuckyTower_9_Scene()
    {
        SceneManager.LoadScene("Luck_9TS");
    }
    public void ChangeTo_MageTower_9_Scene()
    {
        SceneManager.LoadScene("Mage_9TS");
    }
    public void ChangeTo_RunTower_9_Scene()
    {
        SceneManager.LoadScene("Run_9TS");
    }
    public void ChangeTo_JumpTower_9_Scene()
    {
        SceneManager.LoadScene("Jump_9TS");
    }
    public void ChangeTo_ClimbTower_9_Scene()
    {
        SceneManager.LoadScene("Climb_9TS");
    }
    public void ChangeTo_TimingTower_9_Scene()
    {
        SceneManager.LoadScene("Timing_9TS");
    }
    public void ChangeTo_OneHandDrowingTower_9_Scene()
    {
        SceneManager.LoadScene("OHD_9TS");
    }
    public void ChangeTo_DeviceTower_9_Scene()
    {
        SceneManager.LoadScene("Device_9TS");
    }


    //10층
    public void ChangeTo_MathTower_10_Scene()
    {
        SceneManager.LoadScene("Math_10TS");
    }
    public void ChangeTo_LuckyTower_10_Scene()
    {
        SceneManager.LoadScene("Luck_10TS");
    }
    public void ChangeTo_MageTower_10_Scene()
    {
        SceneManager.LoadScene("Mage_10TS");
    }
    public void ChangeTo_RunTower_10_Scene()
    {
        SceneManager.LoadScene("Run_10TS");
    }
    public void ChangeTo_JumpTower_10_Scene()
    {
        SceneManager.LoadScene("Jump_10TS");
    }
    public void ChangeTo_ClimbTower_10_Scene()
    {
        SceneManager.LoadScene("Climb_10TS");
    }
    public void ChangeTo_TimingTower_10_Scene()
    {
        SceneManager.LoadScene("Timing_10TS");
    }
    public void ChangeTo_OneHandDrowingTower_10_Scene()
    {
        SceneManager.LoadScene("OHD_10TS");
    }
    public void ChangeTo_DeviceTower_10_Scene()
    {
        SceneManager.LoadScene("Device_10TS");
    }


    //11층
    public void ChangeTo_MathTower_11_Scene()
    {
        SceneManager.LoadScene("Math_11TS");
    }
    public void ChangeTo_LuckyTower_11_Scene()
    {
        SceneManager.LoadScene("Luck_11TS");
    }
    public void ChangeTo_MageTower_11_Scene()
    {
        SceneManager.LoadScene("Mage_11TS");
    }
    public void ChangeTo_RunTower_11_Scene()
    {
        SceneManager.LoadScene("Run_11TS");
    }
    public void ChangeTo_JumpTower_11_Scene()
    {
        SceneManager.LoadScene("Jump_11TS");
    }
    public void ChangeTo_ClimbTower_11_Scene()
    {
        SceneManager.LoadScene("Climb_11TS");
    }
    public void ChangeTo_TimingTower_11_Scene()
    {
        SceneManager.LoadScene("Timing_11TS");
    }
    public void ChangeTo_OneHandDrowingTower_11_Scene()
    {
        SceneManager.LoadScene("OHD_11TS");
    }
    public void ChangeTo_DeviceTower_11_Scene()
    {
        SceneManager.LoadScene("Device_11TS");
    }


    //2층
    public void ChangeTo_MathTower_12_Scene()
    {
        SceneManager.LoadScene("Math_12TS");
    }
    public void ChangeTo_LuckyTower_12_Scene()
    {
        SceneManager.LoadScene("Luck_12TS");
    }
    public void ChangeTo_MageTower_12_Scene()
    {
        SceneManager.LoadScene("Mage_12TS");
    }
    public void ChangeTo_RunTower_12_Scene()
    {
        SceneManager.LoadScene("Run_12TS");
    }
    public void ChangeTo_JumpTower_12_Scene()
    {
        SceneManager.LoadScene("Jump_12TS");
    }
    public void ChangeTo_ClimbTower_12_Scene()
    {
        SceneManager.LoadScene("Climb_12TS");
    }
    public void ChangeTo_TimingTower_12_Scene()
    {
        SceneManager.LoadScene("Timing_12TS");
    }
    public void ChangeTo_OneHandDrowingTower_12_Scene()
    {
        SceneManager.LoadScene("OHD_12TS");
    }
    public void ChangeTo_DeviceTower_12_Scene()
    {
        SceneManager.LoadScene("Device_12TS");
    }


    //13층
    public void ChangeTo_MathTower_13_Scene()
    {
        SceneManager.LoadScene("Math_13TS");
    }
    public void ChangeTo_LuckyTower_13_Scene()
    {
        SceneManager.LoadScene("Luck_13TS");
    }
    public void ChangeTo_MageTower_13_Scene()
    {
        SceneManager.LoadScene("Mage_13TS");
    }
    public void ChangeTo_RunTower_13_Scene()
    {
        SceneManager.LoadScene("Run_13TS");
    }
    public void ChangeTo_JumpTower_13_Scene()
    {
        SceneManager.LoadScene("Jump_13TS");
    }
    public void ChangeTo_ClimbTower_13_Scene()
    {
        SceneManager.LoadScene("Climb_13TS");
    }
    public void ChangeTo_TimingTower_13_Scene()
    {
        SceneManager.LoadScene("Timing_13TS");
    }
    public void ChangeTo_OneHandDrowingTower_13_Scene()
    {
        SceneManager.LoadScene("OHD_13TS");
    }
    public void ChangeTo_DeviceTower_13_Scene()
    {
        SceneManager.LoadScene("Device_13TS");
    }


    //14층
    public void ChangeTo_MathTower_14_Scene()
    {
        SceneManager.LoadScene("Math_14TS");
    }
    public void ChangeTo_LuckyTower_14_Scene()
    {
        SceneManager.LoadScene("Luck_14TS");
    }
    public void ChangeTo_MageTower_14_Scene()
    {
        SceneManager.LoadScene("Mage_14TS");
    }
    public void ChangeTo_RunTower_14_Scene()
    {
        SceneManager.LoadScene("Run_14TS");
    }
    public void ChangeTo_JumpTower_14_Scene()
    {
        SceneManager.LoadScene("Jump_14TS");
    }
    public void ChangeTo_ClimbTower_14_Scene()
    {
        SceneManager.LoadScene("Climb_14TS");
    }
    public void ChangeTo_TimingTower_14_Scene()
    {
        SceneManager.LoadScene("Timing_14TS");
    }
    public void ChangeTo_OneHandDrowingTower_14_Scene()
    {
        SceneManager.LoadScene("OHD_14TS");
    }
    public void ChangeTo_DeviceTower_14_Scene()
    {
        SceneManager.LoadScene("Device_14TS");
    }


    //15층
    public void ChangeTo_MathTower_15_Scene()
    {
        SceneManager.LoadScene("Math_15TS");
    }
    public void ChangeTo_LuckyTower_15_Scene()
    {
        SceneManager.LoadScene("Luck_15TS");
    }
    public void ChangeTo_MageTower_15_Scene()
    {
        SceneManager.LoadScene("Mage_15TS");
    }
    public void ChangeTo_RunTower_15_Scene()
    {
        SceneManager.LoadScene("Run_15TS");
    }
    public void ChangeTo_JumpTower_15_Scene()
    {
        SceneManager.LoadScene("Jump_15TS");
    }
    public void ChangeTo_ClimbTower_15_Scene()
    {
        SceneManager.LoadScene("Climb_15TS");
    }
    public void ChangeTo_TimingTower_15_Scene()
    {
        SceneManager.LoadScene("Timing_15TS");
    }
    public void ChangeTo_OneHandDrowingTower_15_Scene()
    {
        SceneManager.LoadScene("OHD_15TS");
    }
    public void ChangeTo_DeviceTower_15_Scene()
    {
        SceneManager.LoadScene("Device_15TS");
    }



  



    //아래는 엔딩 씬들 (12개 정도?)

    public void ChangeTo_Ending_1_Scene()
    {
        SceneManager.LoadScene("Ending_1S");
    }
    public void ChangeTo_Ending_2_Scene()
    {
        SceneManager.LoadScene("Ending_2S");
    }
    public void ChangeTo_Ending_3_Scene()
    {
        SceneManager.LoadScene("Ending_3S");
    }
    public void ChangeTo_Ending_4_Scene()
    {
        SceneManager.LoadScene("Ending_4S");
    }
    public void ChangeTo_Ending_5_Scene()
    {
        SceneManager.LoadScene("Ending_5S");
    }
    public void ChangeTo_Ending_6_Scene()
    {
        SceneManager.LoadScene("Ending_6S");
    }
    public void ChangeTo_Ending_7_Scene()
    {
        SceneManager.LoadScene("Ending_7S");
    }
    public void ChangeTo_Ending_8_Scene()
    {
        SceneManager.LoadScene("Ending_8S");
    }
    public void ChangeTo_Ending_9_Scene()
    {
        SceneManager.LoadScene("Ending_9S");
    }
    public void ChangeTo_Ending_10_Scene()
    {
        SceneManager.LoadScene("Ending_10S");
    }
    public void ChangeTo_Ending_11_Scene()
    {
        SceneManager.LoadScene("Ending_11S");
    }
    public void ChangeTo_Ending_12_Scene()
    {
        SceneManager.LoadScene("Ending_12S");
    }

}
