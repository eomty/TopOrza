﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LuckBtn : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Button m_btn = this.transform.GetComponent<Button>();
        //m_btn.onClick.AddListener(fClick);

        LuckBtn c_btn = m_btn.GetComponent<LuckBtn>();
        m_btn.onClick.AddListener(() => { c_btn.btn(); });
    }

    public void btn()
    {
        TopClearSC TCS2 = GameObject.Find("GameManager").GetComponent<TopClearSC>();
        //ChangeScene CS = GameObject.Find("GameManager").GetComponent<ChangeScene>();
        if (TCS2.level_stack == 1)
        {
            //CS.ChangeTo_MathTower_2_Scene(); 안됌 망할
            SceneManager.LoadScene("Luck_2TS");
        }
        if (TCS2.level_stack == 2)
        {
            SceneManager.LoadScene("Luck_3TS");
        }
        if (TCS2.level_stack == 3)
        {
            SceneManager.LoadScene("Luck_4TS");
        }
        if (TCS2.level_stack == 4)
        {
            SceneManager.LoadScene("Luck_5TS");
        }
        if (TCS2.level_stack == 5)
        {
            SceneManager.LoadScene("Luck_6TS");
        }
        if (TCS2.level_stack == 6)
        {
            SceneManager.LoadScene("Luck_7TS");
        }
        if (TCS2.level_stack == 7)
        {
            SceneManager.LoadScene("Luck_8TS");
        }
        if (TCS2.level_stack == 8)
        {
            SceneManager.LoadScene("Luck_9TS");
        }
        if (TCS2.level_stack == 9)
        {
            SceneManager.LoadScene("Luck_10TS");
        }
        if (TCS2.level_stack == 10)
        {
            SceneManager.LoadScene("Luck_11TS");
        }
        if (TCS2.level_stack == 11)
        {
            SceneManager.LoadScene("Luck_12TS");
        }
        if (TCS2.level_stack == 12)
        {
            SceneManager.LoadScene("Luck_13TS");
        }
        if (TCS2.level_stack == 13)
        {
            SceneManager.LoadScene("Luck_14TS");
        }
        if (TCS2.level_stack == 14)
        {
            SceneManager.LoadScene("Luck_15TS");
        }
    }

}