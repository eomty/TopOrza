﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MathQuestion : MonoBehaviour
{
    public GameObject Answer1;
    public GameObject Answer2;
    public GameObject Answer3;
    public GameObject Answer4;
    public GameObject Answer5;



    // 0은 틀린 답 1은 정답
    public int A1 = 0;
    public int A2 = 0;
    public int A3 = 1;
    public int A4 = 0;
    public int A5 = 0;

   

    // Start is called before the first frame update
    void OnMouseDown()
    {
        if(Answer1 == true)
        {
            Debug.Log("1번 버튼을 클릭함");
            if(A1 == 1)
            {
                Debug.Log("정답입니다.");
            }
            else
            {
                Debug.Log("틀렸습니다.");
            }
        }

        else if(Answer2 == true)
        {
            Debug.Log("2번 버튼을 클릭함");
            if (A2 == 1)
            {
                Debug.Log("정답입니다.");
            }
            else
            {
                Debug.Log("틀렸습니다.");
            }
        }
        else if (Answer3 == true)
        {
            Debug.Log("3번 버튼을 클릭함");
            if (A3 == 1)
            {
                Debug.Log("정답입니다.");
            }
            else
            {
                Debug.Log("틀렸습니다.");
            }
        }
        else if (Answer4 == true)
        {
            Debug.Log("4번 버튼을 클릭함");
            if (A4 == 1)
            {
                Debug.Log("정답입니다.");
            }
            else
            {
                Debug.Log("틀렸습니다.");
            }
        }
        else if (Answer5 == true)
        {
            Debug.Log("5번 버튼을 클릭함");
            if (A5 == 1)
            {
                Debug.Log("정답입니다.");
            }
            else
            {
                Debug.Log("틀렸습니다.");
            }
        }
        else
        {
            Debug.Log("오류 발생");
        }
    }
}
